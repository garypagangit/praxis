AI operator Praxis code package — development evidence only

Install numerical dependencies: python -m pip install -r requirements.txt
Verify files: python verify_package.py .
Recompute PX-119 aggregate metrics: python audit_px119.py --evidence PATH_TO_EVIDENCE/PX119
Reproduce fits from the separate private prepared-input folder:
  python reproduce.py --data PATH_TO_PRIVATE_INPUTS --output NEW_OUTPUT_DIRECTORY
Add --include-px118 to refit all 30 original conditions (no paid cloud calls).

Code map:
px119/run.py: weights balances class/groups; features creates the three
representations; evaluate computes confusion/rates; main validates splits,
fits only training data, freezes calibration thresholds, saves predictions,
and applies the frozen-model stress intervention. No commands are executed.
px118/train.py: texts builds lexical/verb/masked views; fit calibrates and
evaluates one model; run adds family exclusions; main runs 30 fixed fits.
px118/prior.py: historical group weights, metrics, split and dedup helpers.
px118/common.py: original command qualification/normalization helpers.
px118/prepare.py and audit_results.py: historical provenance scripts; contain
original local paths and are not portable entry points. Use reproduce.py.
collection/: proposed recorder and plan; container integration still pending.
models/: trusted saved PX-118 models; joblib files can execute code when loaded.

Prepared inputs are separate because source logs require terms/privacy review.
This reproduces qualified-input analysis, not a one-command raw-data download.
The original source parsers remain in the repository's PX-117C and PX-118 dirs.
No matched human/AI dataset or deployment validation is included.
