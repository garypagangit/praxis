"""Temporal evaluation sensitivity measurement."""
