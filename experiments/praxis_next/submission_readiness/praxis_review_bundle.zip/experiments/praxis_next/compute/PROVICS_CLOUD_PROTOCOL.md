# Bounded AWS acquisition and qualification of the small ProvICS subset

September 23, 2026. This operation acquires and qualifies source files; it performs **zero model fits** and does not convert incomplete acquisition into experimental success.

## Payload

Run the committed `data_qualification/acquire_provics.py` on the public README, two physical-state CSVs, and four annotation CSVs. Resolve the author's Hugging Face metadata once to a 40-hex commit, record it, and request all seven files at that immutable revision. Never mix floating `main` downloads in the cloud bundle. Three connections maximum; each file is capped at 100 MB. No PCAP, massive provenance graph, credentials, HF token, or source execution artifact is needed. Keep source bytes and event linkage in the existing private AWS bucket and private local data directory. Public Git contains only code, aggregate qualification reports, and sanitized receipts.

The existing local attempts failed before obtaining bytes. AWS uses an independent ordinary network path; no authentication challenge is solved or bypassed. The gate remains closed unless signal bytes are actually downloaded, hash-bound, parsed, and subsequently qualified. The code intentionally does not automatically certify successful attack outcomes.

## Compute plan

Reuse the existing designated `g5.xlarge` only after authenticated inventory verifies its identity, stopped state, expected account, and stop-on-guest-shutdown behavior. The acquisition itself runs on CPU. GPU hardware is not used merely because it is present, and no GPU speedup claim is made. A later TabM fit requires its own frozen payload and scientific comparison.

The existing `experiments/apt_final/native_graph/cloud_control.py` provides a pre-start EventBridge stop watchdog and one-shot execution control. The scoped `provics_cloud_control.py` wrapper preserves those checks with an explicitly tighter 45-minute outer ceiling, a stop request scheduled at 40 minutes, and a 30-minute worker/publication deadline. Use a new private attempt directory and unique S3 prefix. The acquisition command targets at most 900 seconds after submission, with publication reserved and root-controlled immediate stop afterward. The fallback watchdog is an outer bound, not intended runtime. The reserve is $2 including a $0.75 incidental allowance; it is an estimate rather than a billing receipt.

## Execution and collection

1. Bind the protocol, downloader, worker shell, and bundle builder hashes before launch. Root commits/reviews the executable payload and generated freeze.
2. Upload the checked bundle to the unique private prefix. The existing controller verifies the account, stopped instance and scheduled stop before starting.
3. Wait for SSM Online within the existing bounded readiness window. Send the worker through `AWS-RunShellScript` with an explicit timeout and absolute publication deadline.
4. Worker checks the archive and each file hash, selects an existing Python 3.10–3.13 interpreter with standard venv/ensurepip support, verifies at least 2 GB free disk and ordinary PyPI access, and creates an isolated per-run virtual environment. It installs only binary packages with pinned numpy 2.2.6, pandas 2.3.3 and requests 2.32.5 under a 180-second install cap, then records the full package/runtime versions. Shared environments remain unchanged. Unavailable prerequisites produce a published setup-failure receipt.
5. Download public files normally, qualify actual bytes, and publish the source subset plus reports as a checksummed private result archive. A complete worker run can still report `acquisition_incomplete`.
6. Root requests stop in its unconditional cleanup path and verifies stopped state before deleting only this attempt's watchdog. Collect and verify the result archive; do not extract links, traversal paths, or oversized content.

## Decisions after collection

- No signals: retain acquisition failure, do not fit substitutes labeled as new data.
- Signals acquired: inspect clocks, dimensions, missingness, explicit skipped/failed annotations and event coverage before defining a new study. A physical-only subset is an ICS signal development resource, not validated movement/exfiltration telemetry.
- All identity, shutdown and result checks are factual receipts. Do not claim AWS ran, the host stopped, or data were obtained before those actions are observed.

## Setup amendment after attempt 1

Attempt 1 on September 23, 2026 verified the bundle and bootstrap Python but found no pandas in the candidate environments. It published its failure logs, returned no data, and was verified stopped. This is an environment-setup failure, not a failed data-acquisition or scientific experiment. Attempt 2 uses a new private directory/prefix and adds only the bounded isolated installation and disk/network preflight above. Source revision pinning, seven-file scope, scientific qualification code, stop/cost limits and zero-model-fit scope are unchanged. Attempt 1's frozen bundle and receipts are retained.

## Final storage-readiness amendment after attempt 2

Attempt 2 selected Python 3.10.12, but its original run filesystem had less than the required 2 GB free. It stopped before installing packages or contacting Hugging Face, published its logs, and was verified stopped. The capacity threshold is an operational setup bound, not a scientific acceptance criterion.

The final attempt records `findmnt`, `df`, and actual free bytes for existing mounted filesystems, then selects an already-mounted writable ext3/ext4/xfs/btrfs/zfs filesystem with at least 2 GB free. System pseudo-filesystems and boot mounts are excluded. A unique directory directly under the selected mount avoids accidentally using another nested filesystem. Small diagnostic files are initially written to the original per-run location so a no-capacity result can be published; package/data writes begin only on the qualified location. No mounting, formatting, deleting existing data, changing shared environments, creating volumes, or provisioning instances is allowed. If no filesystem qualifies or the data endpoint fails, publish the inventory/failure and stop; no further automatic retry follows this final attempt. Other execution and scientific bounds remain unchanged.
